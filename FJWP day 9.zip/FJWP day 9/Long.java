package sham;

public class Long {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long a;
        a = 9223372036854775807L;
        System.out.println(a);
	}

}

        
    