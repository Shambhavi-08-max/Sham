package sham;

public class Implicit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		byte a = 15;
        double b;
        b = a;
        System.out.println(b);
	}

}

        
    