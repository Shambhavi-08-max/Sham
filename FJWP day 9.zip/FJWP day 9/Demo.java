package sham;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		byte a;
        a = 127;
        System.out.println(a);
    
	}

}

    
        