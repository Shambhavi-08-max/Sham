package sham;

public class Demo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float a = 45.5f;  
        System.out.println(a);
    
	}

}

        