package sham;

public class SimpleIfDemo {

	public static void main(String[] args) {
		System.out.println("start");
		int num= 1;
		
		if(num <= 10)
		{
			System.out.println(num +"is lesser than or equal to 10");
		}
		System.out.println("End");

	}

}
