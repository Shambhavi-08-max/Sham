package sham;

public class VariableExecution {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age;
		age=20;
		
		String name="Shambhavi";
		System.out.println("Name: "+name);
		System.out.println("Age : "+age);
	}

}
