package sham;

public class Unary {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Increament
				//Post
				int x=5;
				int y= x++;
				System.out.println("X: "+x);
				System.out.println("Y: "+y);
				//Pre
				int a=5;
				int b=++a;
				System.out.println("A: "+a);
				System.out.println("B: "+b);
				
				
		//Decrement
				int c=5;
				int d= c--;
				System.out.println("C: "+c);	
				System.out.println("D: "+d);
			
				int e=5;
				int f=--e;
				System.out.println("E: "+e);
				System.out.println("F: "+f);
				
				
				int x1 = 5;
				int y1 = x++ + ++x + ++x + x++;
				System.out.println("x "+x1);
				System.out.println("y "+y1);
				
				int x2 = 5;
				int y2 = x++ + --x + x-- + x++ + x-- - ++x;
				System.out.println("x "+x2);
				System.out.println("y "+y2);
			}

		}

	


