package sham;

public class IfElseIfDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1=5;
		int num2=10;
		
		if(num1<num2)
		{
			System.out.println(num1 +"is lesser than"+num2);
		}
		else if(num1>num2)
		{
			System.out.println(num1+"is greater than"+num2);
			
		}
		else
		{
			System.out.println(num1+"is equal to"+num2);
		}
	}

}
