package sham;
class Addition1 {
    int c;

    void add(int x, int y) {
        c = x + y;
        System.out.println(c);
    }
}

public class DemoAddition1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Addition ref = new Addition();
        int a, b;
        a = 10;
        b = 20;
        ref.add();
	}

}


        
   