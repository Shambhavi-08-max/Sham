package sham;
class Addition {
    int a, b, c;

    void add() {
        a = 10;
        b = 20;
        c = a + b;
        System.out.println(c);
    }
}

public class DemoAddition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Addition ref = new Addition();
	        ref.add();
	}

}

