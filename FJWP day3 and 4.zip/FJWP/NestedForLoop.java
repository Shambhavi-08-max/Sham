package sham;

public class NestedForLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i = 1; i <= 3; i++) {
            for (int j = 5; j <= 6; j++) {
            System.out.println(i+" "+j);
            }
        }
 
	}

}

        