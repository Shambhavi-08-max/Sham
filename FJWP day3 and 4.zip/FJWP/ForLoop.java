package sham;

public class ForLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=1;i<=5;i++){
            System.out.println(i);
        }
        for(int i=5;i>=1;i--){
            System.out.println(i);
        }
         for (int i = 2; i <= 10; i += 2) {
            System.out.print(i + " ");
        }
	}

}

        
   