package sham;

public class WhileLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("While");
        int n=1;
        while(n<=5){
            System.out.println(n);
            n++;
        }
        System.out.println("do While");
         int x = 1;

        do {
            System.out.println(x);
            x++;
        } while (x <= 5);
    
	}

}

        